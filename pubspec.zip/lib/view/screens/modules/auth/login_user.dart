import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';

class LoginUser extends StatelessWidget {
  const LoginUser({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Stack(
        children: [
          Container(
            color: SEColors.primary,
            height: 200,
            child: Positioned(
                child: Container(
              color: SEColors.background,
              width: 200,
              height: 200,
            )),
          ),
          Container(
            decoration: const BoxDecoration(color: SEColors.white, borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10))),
            height: MediaQuery.of(context).size.height - 200,
            width: double.infinity,
            child: Column(
              children: [Text('Prachi Jain')],
            ),
          )
        ],
      ),
    );
  }
}
