import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';
import 'package:leories/view/utils/theme.dart';
import 'package:leories/view/widgets/home/assestment.dart';
import 'package:leories/view/widgets/home/blocks.dart';

class HomeModule extends StatelessWidget {
  const HomeModule({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      // padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: RichText(
                text: TextSpan(
                    text: 'Hello,',
                    style: MainTheme.lightTheme.textTheme.titleLarge,
                    children: const [TextSpan( text: ' Ashwin Sevak', style: TextStyle(color: SEColors.primary, fontWeight: FontWeight.w600))])
              ),
          ),
          SEAddPost(),
          MainBlocks()
        ],
      ),
    );
  }
}
