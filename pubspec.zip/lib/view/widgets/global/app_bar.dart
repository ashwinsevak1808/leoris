import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';

customAppBar(BuildContext context){
  return AppBar(
    leading: IconButton( iconSize: 24,onPressed: (){}, icon: const Icon(Icons.menu, color: Colors.black,)),
    toolbarHeight: 80,
    backgroundColor:SEColors.background,
    actions:[
      Padding(
        padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
        child: IconButton( 
          iconSize: 40,
          onPressed: (){}, icon: const CircleAvatar(radius: 20, backgroundImage: AssetImage('assets/images/avatar.png'),)),
      )
    ],
  );
}