import 'package:flutter/material.dart';
import 'package:leories/view/utils/theme.dart';

import '../../utils/colors.dart';

class Button extends StatelessWidget {
  final String label;
  final Color color;

  const Button({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton(
            style: ButtonStyle(
                backgroundColor: MaterialStatePropertyAll(color), elevation: const MaterialStatePropertyAll(0), textStyle: MaterialStatePropertyAll(MainTheme.lightTheme.textTheme.bodySmall)),
            onPressed: () {},
            child: Text(label)));
  }
}
