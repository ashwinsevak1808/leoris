import 'package:flutter/material.dart';
import 'package:leories/view/utils/provider/inputfield_prod.dart';
import 'package:leories/view/utils/theme.dart';
import 'package:provider/provider.dart';

class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final TextInputType textInputType;
  final String hintText;
  final String labelText;
  String? Function(String?)? validator;
  bool securetext;
  Widget? iconButton;

  InputField({
    super.key,
    required this.controller,
    required this.label,
    required this.textInputType,
    required this.hintText,
    this.validator,
    this.securetext = false,
    this.iconButton,
    required this.labelText,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<PasswordNotifier>(
      builder: (ctx, val, child) {
        return TextFormField(
          controller: controller,
          decoration: InputDecoration(
              labelText: labelText,
              labelStyle: MainTheme.lightTheme.textTheme.labelSmall,
              label: Text(label),
              hintText: hintText,
              filled: true,
              fillColor: MainTheme.lightTheme.canvasColor,
              hintStyle: MainTheme.lightTheme.textTheme.labelSmall,
              focusedBorder:
                  MainTheme.lightTheme.inputDecorationTheme.focusedBorder,
              enabledBorder:
                  MainTheme.lightTheme.inputDecorationTheme.enabledBorder,
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
              suffixIcon: iconButton),
          keyboardType: textInputType,
          autofocus: false,
          obscureText: securetext,
          validator: validator,
        );
      },
    );
  }
}

// Local Text Input

class SETextInput extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final TextInputType textInputType;
  final String hintText;
  String? Function(String?)? validator;
  bool securetext;
  Widget? iconButton;

  SETextInput({
    super.key,
    required this.controller,
    required this.label,
    required this.textInputType,
    required this.hintText,
    this.validator,
    this.securetext = false,
    this.iconButton,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      maxLines: 2,
      controller: controller,
      decoration: InputDecoration(
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          hintText: hintText,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 0.0, horizontal: 20.0),
          suffixIcon: iconButton),
      keyboardType: textInputType,
      autofocus: false,
      obscureText: securetext,
    );
  }
}
