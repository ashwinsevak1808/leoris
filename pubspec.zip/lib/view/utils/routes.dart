



import 'package:flutter/material.dart';
import 'package:leories/view/screens/home.dart';

var screenIndex = [Home(),Text('ashwin'),Text('ashwin'),Text('ashwin'),Text('ashwin'),];