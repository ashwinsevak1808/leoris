// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

class SEColors {
  static const white = Colors.white;
  static const black12 = Color(0xff24272B);
  static const primary = Color(0xff4B39EF);
  static const secoundry = Color(0xff04429E);
  static const prime = Color(0xff111baf);
  static const background = Color(0xffF1F4F8);
  static const anti_splash_white = Color(0xffbbc1e2);
  static const outer_space = Color(0xffe9ecf9);
  static const black = Color(0xff101213);
  static const rasian_black = Color(0xff24272B);

  static const text_grey = Color(0xFF57636C);
}
