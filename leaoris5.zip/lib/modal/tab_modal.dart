import 'package:flutter/material.dart';

class TabData {
  final String label;
  final Widget content;

  TabData(this.label, this.content);
}