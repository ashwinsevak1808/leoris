import 'package:flutter/material.dart';
import 'package:leories/view/screens/connection.dart';
import 'package:leories/view/utils/provider/onboarding_prod.dart';
import 'package:leories/view/utils/provider/screenchange_prod.dart';
import 'package:leories/view/utils/provider/tab_prod.dart';
import 'package:leories/view/utils/theme.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeNotifier()),
        ChangeNotifierProvider(create: (_) => NavigateToScreen()),
        ChangeNotifierProvider(create: (_) => OnBoardingNotifier()),
        ChangeNotifierProvider(create: (_) => TabControllerProvider()),
      ],
      child: Consumer<ThemeNotifier>(builder: (context, ThemeNotifier notify, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: notify.darkTheme ? MainTheme.darkTheme : MainTheme.lightTheme,
          home: const WidgetConnection(),
        );
      }),
    );
  }
}
