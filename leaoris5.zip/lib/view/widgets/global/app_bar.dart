import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';

final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

customAppBar(BuildContext context) {
  return AppBar(
    backgroundColor: SEColors.background,
    leading: const Text(''),
    actions: [
      Padding(padding: const EdgeInsets.all(10), child: IconButton(onPressed: () {}, icon: const Icon(Icons.search))),
      Padding(
        padding: const EdgeInsets.all(10),
        child: IconButton(
          onPressed: () {
            scaffoldKey.currentState?.openDrawer();
          },
          icon: const Icon(Icons.menu),
        ),
      ),
    ],
  );
}
