import 'package:flutter/material.dart';
import 'package:leories/view/screens/modules/music_liberary/musiclib_module.dart';

class MusicLiberary extends StatelessWidget {
  const MusicLiberary({super.key});

  @override
  Widget build(BuildContext context) {
    return const MusicLiberaryModule();
  }
}
