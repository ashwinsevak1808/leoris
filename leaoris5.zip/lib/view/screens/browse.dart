import 'package:flutter/material.dart';
import 'package:leories/view/screens/modules/browse/browse_module.dart';

class Browse extends StatelessWidget {
  const Browse({super.key});

  @override
  Widget build(BuildContext context) {
    return const BrowseModule();
  }
}
