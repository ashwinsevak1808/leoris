import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';
import 'package:leories/view/utils/theme.dart';

class MusicLiberaryModule extends StatelessWidget {
  const MusicLiberaryModule({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Music Liberary', style: MainTheme.lightTheme.textTheme.labelMedium),
          const SizedBox(height: 20),
          Expanded(
              child: ListView(
            shrinkWrap: true,
            children: [
              Container(
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
                clipBehavior: Clip.hardEdge,
                child: ListTile(
                  dense: true,
                  // shape:ShapeBorder.lerp(, b, t),
                  tileColor: SEColors.primary,
                  leading: const CircleAvatar(radius: 20, backgroundImage: AssetImage('assets/images/avatar1.png')),
                  title: Text('Song Name will be going here', style: MainTheme.lightTheme.textTheme.bodySmall),
                  subtitle: Text('Signer Name', style: MainTheme.lightTheme.textTheme.labelSmall),
                ),
              )
            ],
          ))
        ],
      ),
    );
  }
}
