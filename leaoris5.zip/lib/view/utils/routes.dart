import 'package:flutter/material.dart';
import 'package:leories/view/screens/browse.dart';
import 'package:leories/view/screens/home.dart';
import 'package:leories/view/screens/modules/music_liberary/musiclib_module.dart';
import 'package:leories/view/screens/music_liberary.dart';

var screenIndex = const [
  Home(),
  Browse(),
  MusicLiberary(),
  Text('ashwin'),
  Text('ashwin'),
];
