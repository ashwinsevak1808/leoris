// ignore: file_names

abstract class BaseApiServices {
  Future<dynamic> getApiResponse(String url);
  Future<dynamic> getPostApiResponse(String url, dynamic data);
}
