import 'package:flutter/material.dart';
import 'package:leories/view/utils/provider/screenchange_prod.dart';
import 'package:leories/view/utils/routes.dart';
import 'package:leories/view/widgets/global/app_bar.dart';
import 'package:leories/view/widgets/global/bottom_navigation_bar.dart';
import 'package:provider/provider.dart';

class WidgetConnection extends StatelessWidget {
  const WidgetConnection({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<NavigateToScreen>(context, listen: false);
    return Scaffold(
      body: Consumer<NavigateToScreen>(builder: (context, value, child) {
        return screenIndex[value.pageIndex];
      }),
      appBar: customAppBar(context),
      bottomNavigationBar: customNavigationBar(context),
    );
  }
}
