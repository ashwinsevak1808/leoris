import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';
import 'package:leories/view/utils/provider/screenchange_prod.dart';
import 'package:provider/provider.dart';

customNavigationBar(BuildContext context) {
 
  final provider = Provider.of<NavigateToScreen>(context, listen: false);
  return Consumer<NavigateToScreen>(
    builder: (_, __, ___) {
      return BottomNavigationBar(
        onTap: (index) {
          provider.switchScreen(index);
        },
        items: bottomItems,
        currentIndex: provider.pageIndex,
        backgroundColor: SEColors.background,
        selectedItemColor: SEColors.primary,
        unselectedItemColor: SEColors.text_grey,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        type: BottomNavigationBarType.fixed,
      );
    },
  );
}

var bottomItems = const [
  BottomNavigationBarItem(
      activeIcon: Icon(
        Icons.home_filled,
        size: 25,
      ),
      icon: Icon(
        Icons.home_outlined,
        size: 25,
      ),
      label: "Home"),
  BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
        size: 25,
      ),
      label: "Idealakers"),
  BottomNavigationBarItem(icon: Icon(Icons.home), label: "Add Post"),
  BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
        size: 25,
      ),
      label: "Notification"),
  BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
        size: 25,
      ),
      label: "Account"),
];
