import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';

customAppBar(BuildContext context) {
  return AppBar(
    toolbarHeight: 100,
    backgroundColor: SEColors.background,
    actions: [
      Padding(padding: const EdgeInsets.all(10), child: IconButton(onPressed: () {}, icon: const Icon(Icons.search))),
      Padding(padding: const EdgeInsets.all(10), child: IconButton(onPressed: () {}, icon: const Icon(Icons.menu)))
    ],
  );
}
