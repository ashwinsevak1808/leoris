import 'package:flutter/material.dart';
import 'package:leories/view/utils/colors.dart';
import 'package:leories/view/utils/theme.dart';

class ListenPodcast extends StatelessWidget {
  const ListenPodcast({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(
      children: [Text('Listen podcasts', style: MainTheme.lightTheme.textTheme.headlineLarge)],
    ));
  }
}
