class AppUrl{
  static var newsApiUrl = 'https://appurl.com/apiresponse/key';
}