class OnBoardingContent {
  String image;
  String title;
  String discription;

  OnBoardingContent({required this.image, required this.title, required this.discription});
}
